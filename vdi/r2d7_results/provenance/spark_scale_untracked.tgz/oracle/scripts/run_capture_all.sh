#!/bin/bash
# Capture SF30, SF60, SF100 back to back, converting each as it finishes. Run inside tmux.
# A failed SF does not stop the others; rerunning resumes each SF where it left off.
cd "$(dirname "$0")"
for SF in 30 60 100; do
    echo "=== SF$SF capture start $(date -u +%FT%TZ)"
    ./run_spark_sf.sh capture "$SF" 1-99 > "/mnt/tpcds/results/sf${SF}_capture_console.log" 2>&1
    echo "=== SF$SF capture exit=$? $(date -u +%FT%TZ)"
    ./run_spark_sf.sh convert "$SF" 2>&1 | tail -3
done
echo "=== all done $(date -u +%FT%TZ)"
